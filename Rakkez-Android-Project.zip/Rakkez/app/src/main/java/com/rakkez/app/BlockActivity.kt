package com.rakkez.app

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class BlockActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val left = Store.remaining(this)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(60, 60, 60, 60)
            setBackgroundColor(0xFF1B1B2F.toInt())
        }
        layout.addView(TextView(this).apply {
            text = "📚 ارجع ذاكر!"
            textSize = 32f; setTextColor(0xFFFFFFFF.toInt()); gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = "فاضل لك $left مهمة النهارده، خلّصهم والموبايل يتفتح كله 💪"
            textSize = 18f; setTextColor(0xFFCCCCCC.toInt()); gravity = Gravity.CENTER
            setPadding(0, 30, 0, 50)
        })
        layout.addView(Button(this).apply {
            text = "افتح ركّز"
            setOnClickListener {
                startActivity(Intent(this@BlockActivity, MainActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP))
                finish()
            }
        })
        setContentView(layout)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = goHome()

    private fun goHome() {
        startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
