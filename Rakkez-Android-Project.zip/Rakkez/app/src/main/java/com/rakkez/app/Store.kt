package com.rakkez.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class StudyTask(
    val id: Long,
    val name: String,
    val minutes: Int,
    val studiedSec: Int = 0,
    val done: Boolean = false
) {
    // مينفعش يعلّم "خلصت" قبل ما نص الوقت يعدّي
    val canFinish get() = studiedSec >= minutes * 30
}

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("rakkez", Context.MODE_PRIVATE)

    // التطبيقات الممنوعة وقت الجلسة (ضيف أو شيل زي ما تحب)
    val BLOCKED = setOf(
        "com.facebook.katana", "com.facebook.lite", "com.instagram.android",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.google.android.youtube", "com.snapchat.android",
        "com.twitter.android", "com.reddit.frontpage",
        "com.tencent.ig", "com.dts.freefireth", "com.roblox.client",
        "com.supercell.clashofclans", "com.supercell.brawlstars",
        "com.kiloo.subwaysurf", "com.king.candycrushsaga",
        "com.netflix.mediaclient", "com.facebook.orca"
    )

    fun load(c: Context): List<StudyTask> {
        val arr = JSONArray(prefs(c).getString("tasks", "[]"))
        return (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            StudyTask(o.getLong("id"), o.getString("name"), o.getInt("min"),
                o.getInt("sec"), o.getBoolean("done"))
        }
    }

    fun save(c: Context, tasks: List<StudyTask>) {
        val arr = JSONArray()
        tasks.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name)
                .put("min", it.minutes).put("sec", it.studiedSec).put("done", it.done))
        }
        prefs(c).edit().putString("tasks", arr.toString()).apply()
    }

    // القفل شغال طول ما في مهمة مخلصتش
    fun isFree(c: Context) = prefs(c).getBoolean("free", false)
    fun setFree(c: Context, v: Boolean) = prefs(c).edit().putBoolean("free", v).apply()
    fun pin(c: Context) = prefs(c).getString("pin", "1234") ?: "1234"
    fun setPin(c: Context, p: String) = prefs(c).edit().putString("pin", p).apply()
    fun isLocked(c: Context) = !isFree(c) && load(c).any { !it.done }
    fun remaining(c: Context) = load(c).count { !it.done }
}
