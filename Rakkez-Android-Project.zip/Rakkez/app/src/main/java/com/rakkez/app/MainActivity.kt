package com.rakkez.app

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle.Event
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Screen() } } }
    }

    fun hasUsage(): Boolean {
        val ops = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) ==
                AppOpsManager.MODE_ALLOWED
    }

    fun hasOverlay() = Settings.canDrawOverlays(this)

    fun syncService() {
        if (Store.isLocked(this) && hasUsage()) {
            try { startForegroundService(Intent(this, BlockerService::class.java)) } catch (_: Exception) {}
        }
    }
}

@Composable
fun Screen() {
    val act = LocalContext.current as MainActivity
    var tasks by remember { mutableStateOf(Store.load(act)) }
    var activeId by remember { mutableStateOf<Long?>(null) }
    var usageOk by remember { mutableStateOf(act.hasUsage()) }
    var overlayOk by remember { mutableStateOf(act.hasOverlay()) }
    var name by remember { mutableStateOf("") }
    var mins by remember { mutableStateOf("60") }
    var free by remember { mutableStateOf(Store.isFree(act)) }
    var showAdmin by remember { mutableStateOf(false) }

    fun update(t: List<StudyTask>) { tasks = t; Store.save(act, t); act.syncService() }

    // تحديث حالة الصلاحيات لما يرجع من الإعدادات + إيقاف التايمر لو خرج
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Event.ON_RESUME) { usageOk = act.hasUsage(); overlayOk = act.hasOverlay(); act.syncService() }
            if (e == Event.ON_PAUSE) activeId = null
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // التايمر: بيعدّ ثانية بثانية طالما التطبيق مفتوح والمهمة شغالة
    LaunchedEffect(activeId) {
        val id = activeId ?: return@LaunchedEffect
        while (activeId == id) {
            delay(1000)
            tasks = tasks.map { if (it.id == id) it.copy(studiedSec = it.studiedSec + 1) else it }
            if (tasks.firstOrNull { it.id == id }?.studiedSec?.rem(5) == 0) Store.save(act, tasks)
        }
        Store.save(act, tasks)
    }

    Column(Modifier.fillMaxSize().padding(16.dp).systemBarsPadding()) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("ركّز 📚", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { showAdmin = true }) { Text("🔑 الأخ الكبير") }
        }
        if (showAdmin) AdminDialog(
            act = act, free = free,
            onFree = { v -> free = v; Store.setFree(act, v); act.syncService() },
            onReset = { update(tasks.map { it.copy(studiedSec = 0, done = false) }); activeId = null },
            onDismiss = { showAdmin = false }
        )
        val left = tasks.count { !it.done }
        Text(if (free && left > 0) "🔓 القفل ملغي من الأخ الكبير" else if (tasks.isEmpty()) "ضيف مهام اليوم" else if (left == 0) "🎉 خلّصت كل مهامك! الموبايل مفتوح" else "فاضل $left مهمة، والتطبيقات مقفولة لحد ما تخلصهم")
        Spacer(Modifier.height(8.dp))

        if (!usageOk) Button(onClick = { act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, Modifier.fillMaxWidth()) {
            Text("1) فعّل صلاحية Usage Access")
        }
        if (!overlayOk) Button(onClick = {
            act.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${act.packageName}")))
        }, Modifier.fillMaxWidth()) { Text("2) فعّل Display over other apps") }

        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(name, { name = it }, label = { Text("المادة") }, modifier = Modifier.weight(1f), singleLine = true)
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(mins, { mins = it.filter(Char::isDigit) }, label = { Text("دقايق") },
                modifier = Modifier.width(90.dp), singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        }
        Button(onClick = {
            val m = mins.toIntOrNull() ?: 0
            if (name.isNotBlank() && m > 0) {
                update(tasks + StudyTask(System.currentTimeMillis(), name.trim(), m))
                name = ""
            }
        }, Modifier.fillMaxWidth()) { Text("إضافة مهمة") }

        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(tasks, key = { it.id }) { t ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text((if (t.done) "✅ " else "") + t.name, style = MaterialTheme.typography.titleMedium)
                        val s = t.studiedSec
                        Text("%02d:%02d / %d دقيقة".format(s / 60, s % 60, t.minutes))
                        LinearProgressIndicator(progress = { (s / (t.minutes * 60f)).coerceIn(0f, 1f) }, Modifier.fillMaxWidth())
                        if (!t.done) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            if (activeId == t.id) OutlinedButton(onClick = { activeId = null }) { Text("إيقاف") }
                            else Button(onClick = { activeId = t.id }) { Text("ابدأ") }
                            Button(enabled = t.canFinish, onClick = {
                                if (activeId == t.id) activeId = null
                                update(tasks.map { if (it.id == t.id) it.copy(done = true) else it })
                            }) { Text(if (t.canFinish) "خلصت ✅" else "بعد نص الوقت") }
                            TextButton(onClick = { update(tasks.filter { it.id != t.id }) }) { Text("حذف") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminDialog(act: MainActivity, free: Boolean, onFree: (Boolean) -> Unit, onReset: () -> Unit, onDismiss: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var ok by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf(false) }
    var newPin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("إغلاق") } },
        title = { Text("🔑 الأخ الكبير") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!ok) {
                    OutlinedTextField(pin, { pin = it.filter(Char::isDigit); err = false },
                        label = { Text("الرقم السري") }, singleLine = true, isError = err,
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    Button(onClick = { if (pin == Store.pin(act)) ok = true else { err = true; pin = "" } }) { Text("دخول") }
                    if (err) Text("الرقم السري غلط")
                } else {
                    Text(if (free) "القفل ملغي حاليًا" else "القفل شغال")
                    Button(onClick = { onFree(!free) }) { Text(if (free) "🔒 رجّع القفل" else "🔓 إلغاء القفل") }
                    OutlinedButton(onClick = onReset) { Text("تصفير وقت المهام") }
                    OutlinedTextField(newPin, { newPin = it.filter(Char::isDigit) },
                        label = { Text("رقم سري جديد (4 أرقام+)") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                    OutlinedButton(onClick = { if (newPin.length >= 4) { Store.setPin(act, newPin); newPin = "" } }) { Text("حفظ الرقم") }
                }
            }
        }
    )
}
